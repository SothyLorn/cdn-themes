#!/usr/bin/env bash
# List declared assets per mode and whether they exist.
#   ./check-assets.sh                 # all themes
#   ./check-assets.sh khmer-new-year  # one theme
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
python3 - "${1:-}" <<'PY'
import json, pathlib, sys

only = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] else None
missing = 0

for src in sorted(pathlib.Path("src").iterdir()):
    if not (src / "theme.json").is_file(): continue
    if only and src.name != only: continue
    cfg = json.loads((src / "theme.json").read_text(encoding="utf-8"))
    shared = cfg.get("assets", {})
    print(f"\n{src.name}/  (default mode: {cfg.get('defaultMode','system')})")

    used = set()
    for mode, mcfg in sorted(cfg["modes"].items()):
        print(f"  [{mode}]")
        eff = dict(shared)
        eff.update(mcfg.get("assets", {}))
        eff.update(mcfg.get("animations", {}))
        for key, rel in eff.items():
            used.add(rel)
            ok = (src / rel).is_file()
            missing += 0 if ok else 1
            tag = "shared" if key in shared and key not in mcfg.get("assets", {}) else "  "
            size = f"{(src/rel).stat().st_size:,}B" if ok else ""
            print(f"    {'ok     ' if ok else 'MISSING'} {tag:6} {key:16} {rel:34} {size}")

    for p, label in (("preview.png", "preview light"), ("preview-dark.png", "preview dark")):
        ok = (src / p).is_file()
        missing += 0 if ok else 1
        print(f"  {'ok     ' if ok else 'MISSING'} {label:16} {p}")

    for p in sorted((src / "images").rglob("*")) if (src / "images").is_dir() else []:
        if p.is_file():
            rel = str(p.relative_to(src))
            if rel not in used:
                print(f"  unused  {'':16} {rel}  (packed but never referenced)")

print(f"\n{missing} missing" if missing else "\nall assets present")
sys.exit(1 if missing else 0)
PY
