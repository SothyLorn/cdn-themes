#!/usr/bin/env bash
# Package a theme source directory into a versioned, immutable bundle.
#
#   ./build-bundle.sh khmer-new-year 2027.1
#
# Both light and dark palettes ship in ONE bundle, so switching mode on the
# device is instant and never triggers a download.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$ROOT/src"
DIST_DIR="$ROOT/dist"

THEME="${1:?usage: build-bundle.sh <theme-name> <version>}"
VERSION="${2:?usage: build-bundle.sh <theme-name> <version>}"

SRC="$SRC_DIR/$THEME"
BUNDLE_ID="${THEME}-${VERSION}"
OUT="$DIST_DIR/bundles/$BUNDLE_ID"

[[ -d "$SRC" ]]            || { echo "ERROR: no such theme source: $SRC" >&2; exit 1; }
[[ -f "$SRC/theme.json" ]] || { echo "ERROR: missing $SRC/theme.json" >&2; exit 1; }

# Bundles are immutable once published. Never overwrite - cut a new version.
if [[ -d "$OUT" ]]; then
  echo "ERROR: $BUNDLE_ID already exists. Bundles are immutable - bump the version." >&2
  exit 1
fi

echo "==> Validating $THEME"
python3 - "$SRC" <<'PY'
import json, sys, pathlib

src = pathlib.Path(sys.argv[1])
t = json.loads((src / "theme.json").read_text(encoding="utf-8"))

if t.get("schema") != 2:
    sys.exit(f"  theme.json schema must be 2 (got {t.get('schema')!r})")
for k in ("id", "name", "modes"):
    if k not in t:
        sys.exit(f"  theme.json missing required key: {k}")

modes = t["modes"]
for required in ("light", "dark"):
    if required not in modes:
        sys.exit(f"  modes.{required} is required - every theme must define both")

dm = t.get("defaultMode", "system")
if dm not in ("system", "light", "dark"):
    sys.exit(f"  defaultMode must be system|light|dark (got {dm!r})")

# Colors every mode must define, so the client never hits a missing key.
REQUIRED_COLORS = {
    "primary", "primaryVariant", "secondary", "background", "surface",
    "onPrimary", "onBackground", "onSurface", "success", "warning",
    "error", "divider",
}

shared = t.get("assets", {})
problems, files = [], set()

for mode, cfg in sorted(modes.items()):
    colors = cfg.get("colors", {})
    gap = REQUIRED_COLORS - set(colors)
    if gap:
        problems.append(f"modes.{mode}.colors missing: {sorted(gap)}")
    bad = [f"{k}={v}" for k, v in colors.items()
           if not (isinstance(v, str) and len(v) == 7 and v.startswith("#"))]
    if bad:
        problems.append(f"modes.{mode}.colors not #RRGGBB: {bad}")

    # Effective asset map = shared, overridden per mode.
    eff = dict(shared)
    eff.update(cfg.get("assets", {}))
    eff.update(cfg.get("animations", {}))
    for key, rel in eff.items():
        files.add(rel)
        if not (src / rel).is_file():
            problems.append(f"modes.{mode}: {key} -> {rel} not found")

# Both modes must expose the same asset keys, or one renders incomplete.
keysets = {m: frozenset(set(shared) | set(c.get("assets", {})))
           for m, c in modes.items()}
if len(set(keysets.values())) > 1:
    only = {m: sorted(set(k) ^ set.union(*[set(x) for x in keysets.values()]))
            for m, k in keysets.items()}
    problems.append(f"modes expose different asset keys; missing per mode: {only}")

for p in ("preview.png", "preview-dark.png"):
    if not (src / p).is_file():
        problems.append(f"missing {p}")

if problems:
    sys.exit("\n".join("  " + p for p in problems))

print(f"    ok - modes={sorted(modes)}  shared assets={len(shared)}  "
      f"files={len(files)}  default={dm}")
PY

mkdir -p "$OUT"

echo "==> Packing theme.zip"
# -X drops timestamps and extended attrs so identical input yields an identical
# hash. Previews stay outside the zip - the picker needs them before committing
# to a download, one per mode.
( cd "$SRC" && zip -q -r -X "$OUT/theme.zip" . \
    -x 'preview.png' 'preview-dark.png' '.*' '*/.*' )

cp "$SRC/preview.png"      "$OUT/preview.png"
cp "$SRC/preview-dark.png" "$OUT/preview-dark.png"

SHA="$(sha256sum "$OUT/theme.zip" | awk '{print $1}')"
SIZE="$(stat -c%s "$OUT/theme.zip")"

python3 - "$OUT" "$BUNDLE_ID" "$THEME" "$VERSION" "$SHA" "$SIZE" "$SRC" <<'PY'
import json, sys, pathlib, datetime, os
out, bid, theme, version, sha, size, src = sys.argv[1:8]
t = json.loads((pathlib.Path(src) / "theme.json").read_text(encoding="utf-8"))
meta = {
    "id": bid, "theme": theme, "version": version,
    "sha256": sha, "size": int(size),
    "modes": sorted(t["modes"]),
    "default_mode": t.get("defaultMode", "system"),
    "built_at": datetime.datetime.now(datetime.timezone.utc)
                    .strftime("%Y-%m-%dT%H:%M:%SZ"),
    "built_by": os.environ.get("USER", "ci"),
}
(pathlib.Path(out) / "bundle.meta.json").write_text(
    json.dumps(meta, indent=2) + "\n", encoding="utf-8")
PY

echo "==> Built $BUNDLE_ID"
echo "    sha256 : $SHA"
echo "    size   : $(numfmt --to=iec-i --suffix=B "$SIZE" 2>/dev/null || echo "${SIZE}B")"
echo "    path   : $OUT"
